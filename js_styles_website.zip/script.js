
function toggleMenu(){
const menu=document.getElementById("nav-menu");
menu.style.display = menu.style.display === "flex" ? "none" : "flex";
}

function addToCart(){
alert("Product added to cart!");
}

function filterProducts(category){
const products=document.querySelectorAll(".product");

products.forEach(p=>{
if(category==="all"){
p.style.display="block";
}else{
p.style.display=p.dataset.category===category?"block":"none";
}
});
}

document.querySelectorAll('a[href^="#"]').forEach(anchor=>{
anchor.addEventListener("click",function(e){
e.preventDefault();
document.querySelector(this.getAttribute("href")).scrollIntoView({
behavior:"smooth"
});
});
});
